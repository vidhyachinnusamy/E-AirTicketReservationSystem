package org.cts.dao;

import java.util.List;

public interface ShowInvoiceDao {

	public List showInvoice();

}
