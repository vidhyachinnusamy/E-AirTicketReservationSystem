package org.cts.dao;

public interface EditDao {
	public int editnow(String n);
}
