package org.cts.dao;

import java.util.List;

import org.cts.bean.SearchFlight;

public interface ShowFlightDao {
public List showFlightInfo(SearchFlight d);
}
