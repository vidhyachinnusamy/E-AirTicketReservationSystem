package org.cts.dao;

import org.cts.bean.Registration;

public interface RegisterDao {
public boolean registerData(Registration e);
}
