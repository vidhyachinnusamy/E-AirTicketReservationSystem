package org.cts.service;

import org.cts.bean.Cancel;

public interface CancelService {

	int cancelNow(Cancel cancel);

}
